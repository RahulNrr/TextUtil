import './App.css';
// import About from './components/About';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
// import AddBCounter from './components/AddBCounter';
import React, { useState } from 'react'
function App() {
 const [mode, setMode] = useState('light');

 const toggaleMode = () =>{
  if(mode === 'light'){
   setMode ('dark')
   document.body.style.backgroundColor = '#042743'
  }
  else{
   setMode('light')
   document.body.style.backgroundColor = 'white'
  }
 }
  return (
   <>
   {/* <AddBCounter/> */}
   <Navbar title="TextUtil" mode={mode} toggaleMode={toggaleMode}/>
   <div className="container my-3 mx-2">
   {/* <About/> */}
      </div>
      {/* <Navbar/> */}
      <TextForm heading = "Enter the text to analyze" mode={mode}/>
    </>
  );
}

export default App;
