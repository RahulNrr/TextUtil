import React, {useState} from 'react'

const TextForm = (props) => {
 const handelToUp = ()=>{
  // console.log("Uppercase was clicked" + text);
  let newText = text.toUpperCase();
  setText(newText)
 }
 const handelToLo = ()=>{
  // console.log("Uppercase was clicked" + text);
  let newText = text.toLowerCase();
  setText(newText)
 }
 const handelToCl = () =>{
  setText("")
 }
 const handelToCopy = () =>{
  console.log("copied")
  var text = document.getElementById("myBox")
  text.select();
  text.setSelectionRange(0,9999)
  navigator.clipboard.writeText(text.value)
 }
 const handelToRemove = ()=>{
  let newText = text.split(/[ ]+/)
  setText(newText.join(" "))
 }
 const handelOnChange = (event) =>{
  // console.log("On change");
  setText(event.target.value);
 }
 const [text, setText] = useState("")
 return (
  <>
  <div> 
  <div className="container" style={{color: props.mode==='dark' ? 'white': '#042743'}}>
  <h1>{props.heading}</h1>
       {/* <label style={{padding: '10px', textAlign: 'center'}} for="myBox" className="form-label"></label> */}
<textarea className="form-control" value={text} onChange={handelOnChange} style={{backgroundColor: props.mode==='dark' ? '#34568B': 'white', color: props.mode==='dark' ? 'white': '#042743'}} id="myBox" rows="8"></textarea>
<button className="btn btn-primary mx-2" onClick={handelToUp}>Convert to Uppercase</button>
<button className="btn btn-primary mx-2" onClick={handelToLo}>Convert to Lowercase</button>
<button className="btn btn-primary mx-2" onClick={handelToCl}>Clear Text</button>
<button className="btn btn-primary mx-2" onClick={handelToRemove}>Remove Extra Spaces</button>
<button className="btn btn-primary mx-2 my-3" onClick={handelToCopy} id="myBox">Copy Text</button>

</div>
<div className="container my-2" style={{color: props.mode==='dark' ? 'white': '#042743'}}>

<h1>Your text summary</h1>
<p>{text.split(" ").length} words and {text.length} characters</p>
<p>{0.008*text.split(" ").length} Minutes read</p>
<h2>Preview</h2>
<p>{text.length>0?text: "Enter something in text area to preview it here.."}</p>
 </div>
 </div>
</>
 )
}

export default TextForm
